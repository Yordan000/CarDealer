﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.Data
{
    public static class GlobalConfiguration
    {
        public static string ConnectionString = @"Server=DESKTOP-VTQCMKG\SQLEXPRESS;Database=CarDealer;Integrated Security=True";
    }
}
